import pandas as pd
import pytest

from src.preprocessing import load_dataset, normalize_text


def test_normalize_text_trims_and_collapses_whitespace():
    assert normalize_text("  The\tpackage\nis late.  ") == "The package is late."


@pytest.mark.parametrize("text", ["", "  \n\t"])
def test_normalize_text_rejects_empty_input(text):
    with pytest.raises(ValueError, match="Enter a complaint"):
        normalize_text(text)


def test_normalize_text_rejects_non_string_input():
    with pytest.raises(ValueError, match="must be a string"):
        normalize_text(None)


def test_load_dataset_drops_missing_text_and_labels(tmp_path):
    path = tmp_path / "complaints.csv"
    pd.DataFrame(
        {
            "complaint": ["A valid complaint", None, "Another complaint"],
            "category": ["Billing", "Delivery", None],
        }
    ).to_csv(path, index=False)

    dataset = load_dataset(str(path))

    assert dataset.to_dict("records") == [
        {"complaint": "A valid complaint", "category": "Billing"}
    ]
