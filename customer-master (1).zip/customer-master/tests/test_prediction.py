from pathlib import Path

import pytest

from src.prediction import (
    InsufficientEvidenceError,
    load_model,
    predict_complaint,
)
from src.training import train_and_evaluate


def test_load_model_reports_missing_artifact(tmp_path):
    with pytest.raises(FileNotFoundError, match="Run 'python train_model.py' first"):
        load_model(tmp_path / "missing.joblib")


def test_training_saves_loadable_model_that_predicts_a_category(tmp_path):
    dataset_path = Path(__file__).resolve().parents[1] / "data" / "sample_complaints.csv"
    model_path = tmp_path / "models" / "classifier.joblib"

    artifact = train_and_evaluate(dataset_path, model_path)
    loaded_artifact = load_model(model_path)
    result = predict_complaint(
        "My package is late and the tracking has not changed.",
        loaded_artifact,
    )

    assert loaded_artifact["best_model"] in {
        "Logistic Regression",
        "Multinomial Naive Bayes",
    }
    assert result["category"] in loaded_artifact["labels"]
    assert set(result["probabilities"]) == set(loaded_artifact["labels"])
    assert sum(result["probabilities"].values()) == pytest.approx(1.0)
    assert artifact["train_size"] + artifact["test_size"] > 0


def test_prediction_rejects_complaints_with_no_training_vocabulary(tmp_path):
    dataset_path = Path(__file__).resolve().parents[1] / "data" / "sample_complaints.csv"
    artifact = train_and_evaluate(dataset_path, tmp_path / "classifier.joblib")

    with pytest.raises(InsufficientEvidenceError, match="no words seen during training"):
        predict_complaint("zxqv blorf quux", artifact)
