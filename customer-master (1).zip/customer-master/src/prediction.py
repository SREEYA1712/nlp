"""Load a trained artifact and classify individual complaints."""

from pathlib import Path
from typing import TypedDict, cast

import joblib
from sklearn.pipeline import Pipeline

from src.preprocessing import normalize_text
from src.training import ModelArtifact


class PredictionResult(TypedDict):
    category: str
    probabilities: dict[str, float]


class InsufficientEvidenceError(ValueError):
    """Raised when none of the complaint's words exist in the training vocabulary."""


def load_model(model_path: str | Path) -> ModelArtifact:
    """Load the model bundle produced by the training script."""
    path = Path(model_path)
    if not path.is_file():
        raise FileNotFoundError(
            f"Trained model not found at '{path}'. Run 'python train_model.py' first."
        )

    artifact = joblib.load(path)
    if not isinstance(artifact, dict) or not isinstance(
        artifact.get("model"), Pipeline
    ):
        raise ValueError(f"Model file '{path}' is not a valid trained model artifact.")
    return cast(ModelArtifact, artifact)


def predict_complaint(text: str, artifact: ModelArtifact) -> PredictionResult:
    """Return the predicted category and its model-estimated class probabilities."""
    complaint = normalize_text(text)
    model = artifact["model"]
    vectorizer = model.named_steps["tfidf"]
    if vectorizer.transform([complaint]).nnz == 0:
        raise InsufficientEvidenceError(
            "This complaint contains no words seen during training. "
            "Try adding a little more detail."
        )

    category = str(model.predict([complaint])[0])
    probabilities = model.predict_proba([complaint])[0]
    classifier = model.named_steps["classifier"]
    return {
        "category": category,
        "probabilities": {
            str(label): float(probability)
            for label, probability in zip(classifier.classes_, probabilities)
        },
    }
