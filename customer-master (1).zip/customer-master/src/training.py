"""Model training, evaluation, and persistence."""

import math
from pathlib import Path
from typing import Any, TypedDict

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    precision_recall_fscore_support,
)
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

from src.preprocessing import load_dataset, normalize_text


class ModelArtifact(TypedDict):
    model: Pipeline
    best_model: str
    labels: list[str]
    metrics: dict[str, dict[str, float]]
    classification_report: dict[str, dict[str, float] | float]
    confusion_matrix: list[list[int]]
    test_size: int
    train_size: int


def _build_pipeline(classifier: Any) -> Pipeline:
    """Keep vectorization and classification together to prevent train/test leakage."""
    return Pipeline(
        [
            (
                "tfidf",
                TfidfVectorizer(
                    preprocessor=normalize_text,
                    ngram_range=(1, 2),
                    strip_accents="unicode",
                ),
            ),
            ("classifier", classifier),
        ]
    )


def _evaluate(model: Pipeline, texts: pd.Series, labels: pd.Series) -> dict[str, float]:
    predictions = model.predict(texts)
    precision, recall, f1, _ = precision_recall_fscore_support(
        labels, predictions, average="macro", zero_division=0
    )
    return {
        "accuracy": float(accuracy_score(labels, predictions)),
        "precision": float(precision),
        "recall": float(recall),
        "f1_score": float(f1),
    }


def train_and_evaluate(
    dataset_path: str | Path, model_path: str | Path
) -> ModelArtifact:
    """Compare both classifiers on the same held-out data and save the winner."""
    dataset = load_dataset(str(dataset_path))
    class_counts = dataset["category"].value_counts()
    labels = sorted(class_counts.index.tolist())

    if len(labels) < 2 or class_counts.min() < 2:
        raise ValueError(
            "Training needs at least two categories and at least two examples "
            "for every category."
        )

    # Reserve at least one test row per category while leaving one training row
    # per category. Stratification preserves category proportions in both sets.
    test_size = max(math.ceil(len(dataset) * 0.2), len(labels))
    if len(dataset) - test_size < len(labels):
        raise ValueError(
            "The dataset is too small for a stratified train/test split. "
            "Add more labeled examples."
        )

    train_texts, test_texts, train_labels, test_labels = train_test_split(
        dataset["complaint"],
        dataset["category"],
        test_size=test_size,
        random_state=42,
        stratify=dataset["category"],
    )

    candidates = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Multinomial Naive Bayes": MultinomialNB(),
    }
    fitted_models: dict[str, Pipeline] = {}
    metrics: dict[str, dict[str, float]] = {}

    for name, classifier in candidates.items():
        pipeline = _build_pipeline(classifier)
        pipeline.fit(train_texts, train_labels)
        fitted_models[name] = pipeline
        metrics[name] = _evaluate(pipeline, test_texts, test_labels)

    best_model_name = max(
        candidates,
        key=lambda name: (metrics[name]["f1_score"], name == "Logistic Regression"),
    )
    best_model = fitted_models[best_model_name]
    predictions = best_model.predict(test_texts)
    report = classification_report(
        test_labels,
        predictions,
        labels=labels,
        output_dict=True,
        zero_division=0,
    )

    artifact: ModelArtifact = {
        "model": best_model,
        "best_model": best_model_name,
        "labels": labels,
        "metrics": metrics,
        "classification_report": report,
        "confusion_matrix": confusion_matrix(
            test_labels, predictions, labels=labels
        ).tolist(),
        "test_size": len(test_texts),
        "train_size": len(train_texts),
    }

    destination = Path(model_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(artifact, destination)
    return artifact
