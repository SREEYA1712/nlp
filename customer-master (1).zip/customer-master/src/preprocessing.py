"""Input and dataset preparation helpers."""

import re
from typing import Final

import pandas as pd


REQUIRED_COLUMNS: Final = {"complaint", "category"}


def normalize_text(text: str) -> str:
    """Trim text and collapse repeated whitespace without removing useful words."""
    if not isinstance(text, str):
        raise ValueError("Complaint text must be a string.")

    normalized = re.sub(r"\s+", " ", text).strip()
    if not normalized:
        raise ValueError("Enter a complaint before classifying it.")

    return normalized


def load_dataset(dataset_path: str) -> pd.DataFrame:
    """Load labeled complaints and discard rows that cannot train a classifier."""
    dataset = pd.read_csv(dataset_path)
    missing_columns = REQUIRED_COLUMNS.difference(dataset.columns)
    if missing_columns:
        missing = ", ".join(sorted(missing_columns))
        raise ValueError(f"Dataset is missing required column(s): {missing}.")

    dataset = dataset.loc[:, ["complaint", "category"]].copy()
    dataset["complaint"] = dataset["complaint"].where(
        dataset["complaint"].map(lambda value: isinstance(value, str)), ""
    )
    dataset["complaint"] = dataset["complaint"].map(
        lambda value: re.sub(r"\s+", " ", value).strip()
    )
    dataset["category"] = dataset["category"].map(
        lambda value: value.strip() if isinstance(value, str) else ""
    )
    dataset = dataset.loc[
        dataset["complaint"].ne("") & dataset["category"].ne("")
    ].reset_index(drop=True)

    if dataset.empty:
        raise ValueError("Dataset has no rows with both complaint text and labels.")

    return dataset
