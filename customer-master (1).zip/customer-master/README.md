# NLP-Based Customer Complaint Classification and Routing System

A beginner-friendly Python project that uses text classification to suggest
which support department should handle a customer complaint.

> **Demonstration only:** The included dataset is small and handcrafted. Its
> predictions and evaluation scores are for learning and software testing, not
> evidence of production accuracy. Always have a person review suggested routes.

## Problem statement

Support teams receive complaints in everyday language. Sorting them manually
can take time. This application demonstrates a machine-learning workflow that
turns complaint text into one of six suggested categories: Billing, Delivery,
Technical Support, Account Issues, Product Quality, or Customer Service.

## Features

- A Streamlit interface for entering and classifying complaints.
- A consistent, responsive navy-and-teal visual theme.
- A layered dashboard with an elevated title backdrop and a separate foreground
  panel for the classifier and remaining features.
- Text normalization and TF-IDF word unigrams and bigrams.
- Logistic Regression and Multinomial Naive Bayes trained and compared.
- A stratified held-out evaluation set when the dataset has enough examples.
- Accuracy, macro precision, macro recall, macro F1, a classification report,
  and a confusion matrix.
- A persisted model pipeline that the app loads rather than retrains.
- A category distribution chart and sample complaints to try.
- Basic pytest coverage for input handling, model persistence, and predictions.

## Technology stack

Python, pandas, NumPy, scikit-learn, TF-IDF, Logistic Regression, Multinomial
Naive Bayes, Streamlit, Matplotlib, Seaborn, Joblib, and pytest.

## Architecture and workflow

1. `data/sample_complaints.csv` contains complaint text and its human-provided
   category. Replace this file with a larger labeled CSV using the same two
   column names to experiment with real data.
2. `src/preprocessing.py` checks the dataset columns, removes rows without text
   or labels, and normalizes whitespace without stripping useful words.
3. `train_model.py` calls `src/training.py`, which creates a stratified
   train/test split before fitting TF-IDF. The vectorizer is part of each
   scikit-learn pipeline, so its vocabulary is learned from training text only.
4. Both classifiers are evaluated on the same held-out complaints. The one
   with the higher **macro F1-score** is selected (Logistic Regression wins
   ties). The metrics and trained pipeline are saved together in a Joblib file.
5. `app.py` loads that saved artifact and `src/prediction.py` classifies new
   input. If no trained vocabulary terms match the input, the app asks for more
   detail instead of presenting an unsupported prediction.

## Project structure

```text
customer-compaint-classifier/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── .gitignore
├── .streamlit/
│   └── config.toml
├── data/
│   └── sample_complaints.csv
├── models/
│   └── .gitkeep
├── src/
│   ├── __init__.py
│   ├── preprocessing.py
│   ├── training.py
│   └── prediction.py
└── tests/
    ├── test_preprocessing.py
    └── test_prediction.py
```

## Installation (Windows PowerShell)

Use Python 3.10 or newer. Run these commands in PowerShell from the project folder:

```powershell
cd "C:\path\to\customer-compaint-classifier"
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks virtual-environment activation, allow scripts for just the
current terminal session and try activation again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## Train the model

Run this after installing dependencies and whenever you replace the dataset:

```powershell
python train_model.py
```

The script prints the measured holdout metrics and saves the selected pipeline
and evaluation results to `models/complaint_classifier.joblib`. The scores are
calculated from the sample data at run time; no accuracy result is promised in
advance.

## Run the application

From the project folder, with the virtual environment active:

```powershell
streamlit run app.py
```

Streamlit prints a local URL (usually `http://localhost:8501`) to open in your
browser. If the model file is missing, train it first with `python train_model.py`.

## Run tests

```powershell
python -m pytest
```

The prediction test checks that the result is a category in the known label set;
it does not assume a tiny dataset makes perfect predictions.

## Dataset and replacing the sample data

The demonstration CSV has 12 example complaints for each supported category.
Rows must have non-empty `complaint` and `category` values. Keep the column
names unchanged when replacing the sample file. Missing rows are dropped;
training reports a clear error if there are fewer than two categories or too
few labeled examples for a stratified split. For meaningful evaluation, use a
representative, larger dataset, check label quality, and consider a separate
final test set.

## Evaluation metrics

- **Accuracy:** fraction of all test complaints assigned the right category.
- **Precision:** how often predictions for a category are correct.
- **Recall:** how many of a category's actual examples are found.
- **Macro F1-score:** the unweighted average F1 across categories. It is the
  selection metric, so small classes count as much as large ones.
- **Confusion matrix:** counts correct and incorrect category assignments.

Reported scores describe only a single small random-seed-42 stratified holdout.
They can vary with the dataset and do not guarantee future performance.
Estimated class probabilities are not necessarily calibrated confidence scores.

## Limitations

- Handcrafted demonstration examples cannot represent the variety of real
  customer language, products, regions, or class balance.
- TF-IDF and these classifiers learn word patterns; they do not understand
  intent or guarantee that a route is correct.
- New topics and wording outside the training vocabulary may not have enough
  evidence for a useful prediction.
- The demonstration split is small, so evaluation metrics are noisy.
- Predictions and class probabilities should not replace human review.

## Future improvements

- Train and validate on a larger, privacy-reviewed, representative dataset.
- Add cross-validation, thresholding, and probability calibration checks.
- Track label quality, model versions, and performance drift.
- Add a feedback flow for humans to correct suggested categories.
- Consider multi-label routing if real complaints can require multiple teams.

## GitHub repository description

> Beginner-friendly Streamlit app that uses TF-IDF and scikit-learn to classify
> customer complaints into support departments, compare two baseline models,
> and visualize evaluation results. Includes a small demonstration dataset,
> tests, and Windows setup instructions. Not intended for production accuracy.

## Upload the project to GitHub

Create an empty repository on GitHub (do not add a README or license there),
then run these commands from this project folder, replacing the URL with your
repository's HTTPS or SSH URL:

```powershell
git init
git add .
git commit -m "Add complaint classification demo"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

The generated `.joblib` model and local virtual environment are excluded by
`.gitignore`. Anyone cloning the project should install requirements and run
`python train_model.py` to create their own model artifact.
