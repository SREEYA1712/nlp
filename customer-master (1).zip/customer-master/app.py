"""Streamlit interface for the customer complaint classification demo."""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import streamlit as st

from src.prediction import InsufficientEvidenceError, load_model, predict_complaint
from src.preprocessing import load_dataset


PROJECT_ROOT = Path(__file__).resolve().parent
MODEL_PATH = PROJECT_ROOT / "models" / "complaint_classifier.joblib"
DATASET_PATH = PROJECT_ROOT / "data" / "sample_complaints.csv"
SAMPLE_COMPLAINTS = [
    "I was charged twice for my monthly plan.",
    "My package is late and the tracking has not changed.",
    "The app crashes when I try to open my account.",
    "I cannot reset my password because I never receive the email.",
    "The new item broke after one day of use.",
    "I have contacted support several times and nobody replied.",
]

st.set_page_config(page_title="Customer Complaint Classifier", page_icon="📬")
st.markdown(
    """
    <style>
    :root {
        color-scheme: light;
    }
    .stApp {
        background:
            radial-gradient(ellipse at 8% 0%, rgba(13, 148, 136, 0.09), transparent 32rem),
            linear-gradient(180deg, #f3f7fa 0%, #f8fafc 50%, #eef3f7 100%);
        color: #172b3a;
    }
    p, label, [data-testid="stWidgetLabel"] p {
        color: #263c4d;
    }
    [data-testid="stHeader"] {
        background: rgba(243, 247, 250, 0.82);
    }
    [data-testid="stAppViewContainer"] .main .block-container {
        max-width: 1120px;
        padding-top: 1.5rem;
        padding-bottom: 4rem;
    }
    .hero {
        position: relative;
        overflow: hidden;
        margin: 0;
        padding: 2.4rem 2.4rem 3.2rem;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 22px;
        background: linear-gradient(125deg, #10283f 0%, #173c55 58%, #0f766e 125%);
        box-shadow: 0 22px 48px rgba(20, 45, 66, 0.2);
        color: #f8fbff;
    }
    .hero::after {
        position: absolute;
        top: -110px;
        right: -45px;
        width: 300px;
        height: 300px;
        border: 1px solid rgba(255, 255, 255, 0.13);
        border-radius: 50%;
        box-shadow: 0 0 0 34px rgba(255, 255, 255, 0.035),
                    0 0 0 70px rgba(255, 255, 255, 0.025);
        content: "";
        pointer-events: none;
    }
    .hero h1 {
        max-width: 900px;
        margin: 0;
        color: #ffffff;
        font-size: clamp(2rem, 4vw, 3rem);
        font-weight: 700;
        letter-spacing: -0.045em;
        line-height: 1.12;
    }
    .st-key-dashboard_panel {
        position: relative;
        z-index: 2;
        margin-top: -1.75rem !important;
        padding: 1.15rem 1.15rem 1.35rem;
        border: 1px solid #dce6ec;
        border-radius: 20px;
        background: #ffffff;
        box-shadow: 0 18px 42px rgba(24, 48, 66, 0.13);
    }
    [data-testid="stTextArea"] textarea,
    [data-testid="stSelectbox"] [data-baseweb="select"] > div {
        border-color: #cedbe3;
        border-radius: 10px;
        background: #ffffff !important;
        color: #172b3a !important;
    }
    [data-testid="stSelectbox"] [data-baseweb="select"] input,
    [data-testid="stTextArea"] textarea {
        color: #172b3a !important;
    }
    [data-testid="stTextArea"] textarea:focus {
        border-color: #0f766e;
        box-shadow: 0 0 0 1px #0f766e;
    }
    [data-testid="stBaseButton-primary"] {
        min-height: 2.8rem;
        border: 0;
        border-radius: 10px;
        background: linear-gradient(105deg, #0f766e, #128579);
        box-shadow: 0 5px 14px rgba(15, 118, 110, 0.2);
        color: #ffffff;
        font-weight: 650;
    }
    [data-testid="stBaseButton-primary"]:hover {
        border: 0;
        background: linear-gradient(105deg, #0b625c, #0f766e);
        color: #ffffff;
    }
    .stButton [data-testid="stBaseButton-primary"] p {
        color: #ffffff;
    }
    h2, h3 {
        color: #163247;
        letter-spacing: -0.025em;
    }
    [data-testid="stCaptionContainer"] {
        color: #637887;
    }
    [data-testid="stAlert"] {
        border-radius: 12px;
    }
    [data-testid="stAlert"] p {
        color: #263c4d;
    }
    @media (max-width: 640px) {
        [data-testid="stAppViewContainer"] .main .block-container {
            padding: 1rem 1rem 2.5rem;
        }
        .hero {
            padding: 1.8rem 1.35rem 3rem;
            border-radius: 17px;
        }
        .st-key-dashboard_panel {
            margin-top: -1.4rem;
            padding: 0.85rem 0.8rem 1rem;
            border-radius: 16px;
        }
    }
    </style>
    """,
    unsafe_allow_html=True,
)
st.markdown(
    """
    <section class="hero">
      <h1>Customer Complaint Classification</h1>
    </section>
    """,
    unsafe_allow_html=True,
)

with st.container(border=True, key="dashboard_panel"):
    st.warning(
        "This project uses a small sample dataset for learning. Its predictions and "
        "evaluation scores are not reliable measures of production performance."
    )

    try:
        artifact = load_model(MODEL_PATH)
    except FileNotFoundError as error:
        st.error(str(error))
        st.info("From the project folder, run `python train_model.py`, then refresh this page.")
        st.stop()
    except (OSError, ValueError) as error:
        st.error(f"Could not load the trained model: {error}")
        st.stop()

    st.subheader("Classify a complaint")
    selected_sample = st.selectbox(
        "Optional: choose an example complaint",
        ["Choose a sample"] + SAMPLE_COMPLAINTS,
    )
    complaint = st.text_area(
        "What happened?",
        value="" if selected_sample == "Choose a sample" else selected_sample,
        height=130,
        placeholder="For example: I was charged twice for my monthly plan.",
    )

    if st.button("Classify complaint", type="primary"):
        try:
            result = predict_complaint(complaint, artifact)
            st.success(f"Suggested department: **{result['category']}**")
            st.caption(
                "This is a suggested routing category based on learned word patterns. "
                "Please review it rather than assuming it is always correct."
            )
            st.markdown("**Estimated class probabilities**")
            st.caption(
                "These probabilities are model outputs, not calibrated confidence scores."
            )
            probabilities = result["probabilities"]
            st.bar_chart(
                pd.Series(probabilities).sort_values(ascending=False),
                horizontal=True,
            )
        except InsufficientEvidenceError as error:
            st.warning(str(error))
        except ValueError as error:
            st.warning(str(error))

    st.divider()
    st.subheader("Model and dataset dashboard")
    st.write(
        f"Selected model: **{artifact['best_model']}**. "
        "Models are compared using macro F1-score, which gives each category equal weight."
    )
    metrics_frame = pd.DataFrame(artifact["metrics"]).T
    st.dataframe(metrics_frame.style.format("{:.3f}"))
    st.caption(
        f"Evaluation used {artifact['test_size']} held-out complaints; "
        f"{artifact['train_size']} complaints were used for training. "
        "The test set is kept separate from TF-IDF fitting."
    )

    try:
        dataset = load_dataset(str(DATASET_PATH))
    except (OSError, ValueError) as error:
        st.error(f"Could not load the dataset for the category chart: {error}")
    else:
        category_counts = dataset["category"].value_counts().sort_values()
        left, right = st.columns(2)
        with left:
            st.markdown("**Complaints by category**")
            st.bar_chart(category_counts, horizontal=True)
        with right:
            st.markdown("**Selected model: confusion matrix**")
            figure, axis = plt.subplots(figsize=(7, 5))
            sns.heatmap(
                artifact["confusion_matrix"],
                annot=True,
                fmt="d",
                cmap="Blues",
                xticklabels=artifact["labels"],
                yticklabels=artifact["labels"],
                ax=axis,
            )
            axis.set_xlabel("Predicted category")
            axis.set_ylabel("Actual category")
            axis.tick_params(axis="x", labelrotation=35)
            figure.tight_layout()
            st.pyplot(figure)
            plt.close(figure)

    with st.expander("View the selected model's classification report"):
        st.dataframe(pd.DataFrame(artifact["classification_report"]).T)
