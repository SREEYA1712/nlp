"""Train and compare the complaint classification models."""

from pathlib import Path

from src.training import train_and_evaluate


PROJECT_ROOT = Path(__file__).resolve().parent
DATASET_PATH = PROJECT_ROOT / "data" / "sample_complaints.csv"
MODEL_PATH = PROJECT_ROOT / "models" / "complaint_classifier.joblib"


def main() -> None:
    artifact = train_and_evaluate(DATASET_PATH, MODEL_PATH)
    print(f"Trained on {artifact['train_size']} complaints.")
    print(f"Evaluated on {artifact['test_size']} held-out complaints.")
    print(f"Selected model by macro F1-score: {artifact['best_model']}")
    for name, scores in artifact["metrics"].items():
        print(
            f"{name}: accuracy={scores['accuracy']:.3f}, "
            f"precision={scores['precision']:.3f}, "
            f"recall={scores['recall']:.3f}, "
            f"macro F1={scores['f1_score']:.3f}"
        )
    print(f"Saved model artifact to: {MODEL_PATH}")
    print("These scores are only a demonstration on a small sample dataset.")


if __name__ == "__main__":
    main()
